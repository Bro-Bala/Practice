package com.akkodis.payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akkodis.payroll.entity.Employee;
import com.akkodis.payroll.exception.PayrollException;
import com.akkodis.payroll.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService EmployeeService;

	@GetMapping("/api")
	public ResponseEntity<List<Employee>> findAll() {
		List<Employee> employees = EmployeeService.findAll();
		if(employees==null || employees.isEmpty()) 
			throw new PayrollException("Employees not found!");
			
		//return new ResponseEntity<List<Employee>>(employees, new HttpHeaders(), HttpStatus.OK);
		return ResponseEntity.ok(employees);
	}

	/**
	 * @param employeeId
	 * @param financialyear 2023-2024
	 * @return
	 */
	public ResponseEntity<Employee> getEmployeeTax(@PathVariable Integer employeeId, @PathVariable String financialyear) {
		Employee employee = EmployeeService.getEmployeeTax(employeeId, financialyear);
		if(employee==null) 
			throw new PayrollException("Employee not found!");
		
		return new ResponseEntity<Employee>(employee,
				new HttpHeaders(), HttpStatus.OK);
	}
}
