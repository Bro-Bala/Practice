package com.akkodis.payroll.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akkodis.payroll.entity.Employee;
import com.akkodis.payroll.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public List<Employee> findAll() {
		
		return employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeTax(Integer employeeId, String finnacialYear) {
		//Form Finacial year date
		int index = finnacialYear.indexOf("-");
		String startDate = "01-04-"+finnacialYear.substring(0, index);
		String endDate = "31-03-"+finnacialYear.substring(index+1);
		Employee employee = null;
		
		employee = employeeRepository.findEmployeeNeedTaxCalculation(employeeId,startDate,endDate);
		//Need to calculate tax for whole year if above query is empty 
		if (employee == null) {
			employee = employeeRepository.findById(employeeId).get();
		}
		//Calculate tax and save to table
		double annualSalary = calculateAnnualSalary(employee);
		double taxAmount = calculateTaxAmount(annualSalary);
                double cessAmount = calculateCessAmount(annualSalary);
		
		//Save tax to DB
		employeeRepository.save(employee);
						
		return employee;
	}
    private double calculateAnnualSalary(Employee employee) 
    {
        LocalDate currentDate = LocalDate.now();
        LocalDate joiningDate = LocalDate.parse(employee.getDateOfJoining(), DateTimeFormatter.ISO_LOCAL_DATE);

        // Calculate number of months worked
        int monthsWorked = 12 * (currentDate.getYear() - joiningDate.getYear()) + currentDate.getMonthValue() - joiningDate.getMonthValue();
        if (joiningDate.getDayOfMonth() > 15) {
            monthsWorked--; // Exclude the month of joining if joined after the 15th
        }

        // Consider only the months from May to March for the financial year
        if (joiningDate.getMonthValue() > Month.MAY.getValue()) {
            monthsWorked -= joiningDate.getMonthValue() - Month.MAY.getValue();
        } else if (joiningDate.getMonthValue() == Month.MAY.getValue() && joiningDate.getDayOfMonth() > 16) {
            monthsWorked--; // Exclude May if joined after the 16th
        }

        // Calculate total salary
        double totalSalary = employee.getSalaryPerMonth() * monthsWorked;
        return totalSalary;
    }

    private double calculateTaxAmount(double annualSalary) {
        double taxAmount = 0;
        if (annualSalary > 1000000) {
            taxAmount += (annualSalary - 1000000) * 0.2;
            annualSalary = 1000000;
        }
        if (annualSalary > 500000) {
            taxAmount += (annualSalary - 500000) * 0.1;
            annualSalary = 500000;
        }
        if (annualSalary > 250000) {
            taxAmount += (annualSalary - 250000) * 0.05;
        }
        return taxAmount;
    }

    private double calculateCessAmount(double annualSalary) {
        if (annualSalary > 2500000) {
            return (annualSalary - 2500000) * 0.02;
        }
        return 0;
    }
}


}
