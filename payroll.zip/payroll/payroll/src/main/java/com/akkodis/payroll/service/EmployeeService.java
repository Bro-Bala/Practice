package com.akkodis.payroll.service;

import java.util.List;
import java.util.Optional;

import com.akkodis.payroll.entity.Employee;


public interface EmployeeService {
	
	List<Employee> findAll();
	
	Employee getEmployeeTax(Integer employeeId, String financalYear);
	
}
