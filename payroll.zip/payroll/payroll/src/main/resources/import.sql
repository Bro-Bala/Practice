INSERT INTO employee(employee_id,first_name,last_name,email,phone_number,doj,salary,tax) VALUES
  (1,'Rama', 'D','rama@infinity.com','945678541','2023-04-01',5000000,0),
  (2,'Sita','R','sita@infinity.com','945678540','2023-06-01',5000000,0),
  (3,'Lakshmana','D','lakshmana@infinity.com','945678542','2023-04-01',4000000,0),
  (4,'Urmila','L','urmila@infinity.com','945678543','2020-08-15',500000,0);